/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author justincobb
 */
public class StarsFile {
    
    public void writeStarEmployee(Employee em) throws IOException {
      File stars = new File("stars.txt");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(stars, true))) {
            bw.write(em.getEmployeeIdInput());
            bw.write(", ");
            bw.write(em.getFirstNameInput());
            bw.write(" ");
            bw.write(em.getLastNameInput());
            bw.write(", ");
            bw.write(em.getOfficeSuppliesSoldInput());
            bw.write(", ");
            bw.write(em.getPaperSoldInput());
            bw.write(", ");
            bw.write(em.getBooksSoldInput());
            bw.write(", ");
            bw.write(em.getButtonGroup2());
            bw.write(", ");
            bw.write(em.getButtonGroup3());
            bw.newLine();
            bw.close();
        }
    
    }
}
