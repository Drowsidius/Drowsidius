/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author justincobb
 */
public class Employee 
{
    private String firstNameInput;
    private String lastNameInput;
    private String employeeIdInput;
    private String officeSuppliesSoldInput;
    private String paperSoldInput;
    private String booksSoldInput;
    private String buttonGroup2;
    private String buttonGroup3;

    public String getFirstNameInput() {
        return firstNameInput;
    }

    public void setFirstNameInput(String firstNameInput) {
        this.firstNameInput = firstNameInput;
    }

    public String getLastNameInput() {
        return lastNameInput;
    }

    public void setLastNameInput(String lastNameInput) {
        this.lastNameInput = lastNameInput;
    }

    public String getEmployeeIdInput() {
        return employeeIdInput;
    }

    public void setEmployeeIdInput(String employeeId) {
        this.employeeIdInput = employeeId;
    }

    public String getOfficeSuppliesSoldInput() {
        return officeSuppliesSoldInput;
    }

    public void setOfficeSuppliesSoldInput(String officeSuppliesSoldInput) {
        this.officeSuppliesSoldInput = officeSuppliesSoldInput;
    }

    public String getPaperSoldInput() {
        return paperSoldInput;
    }

    public void setPaperSoldInput(String paperSoldInput) {
        this.paperSoldInput = paperSoldInput;
    }

    public String getBooksSoldInput() {
        return booksSoldInput;
    }

    public void setBooksSoldInput(String booksSoldInput) {
        this.booksSoldInput = booksSoldInput;
    }


    public String getButtonGroup2() {
        return buttonGroup2;
    }

    public void setButtonGroup2(String buttonGroup2) {
        this.buttonGroup2 = buttonGroup2;
    }

    public String getButtonGroup3() {
        return buttonGroup3;
    }

    public void setButtonGroup3(String buttonGroup3) {
        this.buttonGroup3 = buttonGroup3;
    }

    @Override
    public String toString() {
        return "Employee{" + "firstNameInput=" + firstNameInput + ", lastNameInput=" + lastNameInput + ", employeeIdInput=" + employeeIdInput + ", "
                + "officeSuppliesSoldInput=" + officeSuppliesSoldInput + ", paperSoldInput=" + paperSoldInput + ", booksSoldInput=" + booksSoldInput + ","
                + " buttonGroup2=" + buttonGroup2 + ", buttonGroup3=" + buttonGroup3 + '}';
    }

    Object setOfficeSuppliesSoldInput(Double supplies) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setPaperSoldInput(Double paper) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setBooksSoldInput(Double books) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    


    
    
    
}
