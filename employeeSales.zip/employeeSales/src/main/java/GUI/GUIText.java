
package GUI;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author justincobb
 */
public class GUIText {
    
    
    public void writeEmployee(Employee emp) throws IOException {
      File textFile = new File("salesrep.txt");
        try (BufferedWriter out = new BufferedWriter(new FileWriter(textFile, true))) {
            out.write(emp.getEmployeeIdInput());
            out.write(", ");
            out.write(emp.getFirstNameInput());
            out.write(" ");
            out.write(emp.getLastNameInput());
            out.write(", ");
            out.write(emp.getOfficeSuppliesSoldInput());
            out.write(", ");
            out.write(emp.getPaperSoldInput());
            out.write(", ");
            out.write(emp.getBooksSoldInput());
            out.write(", ");
            out.write(emp.getButtonGroup2());
            out.write(", ");
            out.write(emp.getButtonGroup3());
            out.newLine();
            out.close();
        }
    
    
    } 
}
