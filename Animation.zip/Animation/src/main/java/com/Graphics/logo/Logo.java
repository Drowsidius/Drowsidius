/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Graphics.logo;

import javax.swing.JFrame;

/**
 *
 * @author justincobb
 */
public class Logo {
    public static void main(String[] args) {
        
        JFrame window = new JFrame("Justin's Logo");
        window.setBounds(2000,0, 1000,1000);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        
        MiniGolfLogo logo = new MiniGolfLogo();
        window.add(logo);
        Animator a = new Animator(logo);
    }
}
