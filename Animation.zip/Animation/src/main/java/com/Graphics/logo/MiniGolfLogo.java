
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Graphics.logo;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import javax.swing.JPanel;

/**
 *
 * @author justincobb
 */
public class MiniGolfLogo extends JPanel {
    
    private int whichBall;
    private int whichClub;

    public int getWhichClub() {
        return whichClub;
    }

    public void setWhichClub(int whichClub) {
        this.whichClub = whichClub;
    }

    public int getWhichBall() {
        return whichBall;
    }

    public void setWhichBall(int whichBall) {
        this.whichBall = whichBall;
    }
    
    @Override
    public void paint(Graphics g1) {
        Graphics2D g = (Graphics2D) g1;
        
       g.setColor(Color.BLUE);
        g.fillRect(0, 0, this.getWidth(), this.getHeight()/2);
        g.setColor(Color.GREEN);
        g.fillRect(0, this.getHeight()/2, this.getWidth(), this.getHeight()/2);
        
switch(whichClub){
    default:
    case 1:
        g.setColor(Color.BLACK);
        g.fillRect(1, 300, 30, 100);
        
        g.setColor(Color.GRAY);
        g.fillRect(1, 370, 30, 300);
        
        g.setColor(Color.darkGray);
        g.fillRect(1, 670, 53, 63);
        break;
    case 2:
        g.setColor(Color.BLACK);
        g.fillRect(60, 300, 30, 100);
        
        g.setColor(Color.GRAY);
        g.fillRect(60, 370, 30, 300);
        
        g.setColor(Color.darkGray);
        g.fillRect(60, 670, 53, 63);
        break;
}
        g.setColor(Color.BLACK);
        g.fillOval(700, 690, 50, 40);
 

        
        switch(whichBall) {
            default:
            case 1:
        g.setColor(Color.white);
        g.fillOval(113, 690, 40, 40);
        break;
            case 2:
        g.setColor(Color.white);
        g.fillOval(210, 690, 40, 40);
        break;
            case 3:
        g.setColor(Color.white);       
        g.fillOval(310, 690, 40, 40);
        break;
            case 4:
        g.setColor(Color.white);        
        g.fillOval(410, 690, 40, 40);
        break;
            case 5:
        g.setColor(Color.white);        
        g.fillOval(510, 690, 40, 40);
        break;
            case 6:
        g.setColor(Color.white);        
        g.fillOval(610, 690, 40, 40);
        break;
            case 7:
        g.setColor(Color.white);        
        g.fillOval(705, 690, 40, 40);
        
        g.setColor(Color.red);
        Font f = g.getFont();
        g.setFont(new Font(f.getName(), Font.BOLD, f.getSize() + 75));
        int startX = 0;
        int startY = 0;
        g.drawString("HOLE IN 1!!", startX + 400, startY + 200);
        break;
    }
        g.setColor(Color.WHITE);
        g.fillRect(720, 400, 5, 300);
        
        GeneralPath flag = new GeneralPath();
        int startX = 720;
        int startY = 300;
        flag.moveTo(startX, startY);
        flag.lineTo(startX, startY + 150);
        flag.lineTo(startX + 200, startY + 90);
g.setColor(Color.ORANGE);
g.fill(flag);


    }
}
