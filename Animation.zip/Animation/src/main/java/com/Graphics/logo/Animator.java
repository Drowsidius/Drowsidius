/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Graphics.logo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/**
 *
 * @author justincobb
 */
public class Animator implements ActionListener {
    
    private MiniGolfLogo logo;
    
    public Animator(MiniGolfLogo logo) {
    
    this.logo = logo;
    Timer t = new Timer(750, this);
    t.start();

}

    @Override
    public void actionPerformed(ActionEvent e) {
        logo.setWhichClub(logo.getWhichClub() + 1);
        if(logo.getWhichClub() > 7){
            logo.setWhichClub(0);
        }
        logo.repaint();
        logo.setWhichBall(logo.getWhichBall() + 1);
        if(logo.getWhichBall() > 7){
            logo.setWhichBall(0);
        }
        logo.repaint();
    }
}   